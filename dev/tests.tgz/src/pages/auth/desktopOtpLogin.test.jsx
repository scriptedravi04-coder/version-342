// v348 (Ravi): desktop /login gets "Login with OTP" (same routes as the app) and offers it after a wrong password.
import { describe, it, expect, vi, beforeEach } from "vitest";
import React from "react";
import fs from "fs";
import path from "path";
import { render, screen, cleanup, fireEvent, waitFor } from "@testing-library/react";
import { MemoryRouter, Routes, Route } from "react-router-dom";

const apiMock = vi.hoisted(() => ({ get: vi.fn(), post: vi.fn() }));
const auth = vi.hoisted(() => ({ login: vi.fn(), refreshUser: vi.fn(), setUser: vi.fn() }));
vi.mock("../../lib/api", () => ({ api: apiMock }));
vi.mock("../../lib/useDemoLogin", () => ({ default: () => false }));
vi.mock("sonner", () => ({ toast: { success: vi.fn(), error: vi.fn(), info: vi.fn(), loading: vi.fn() } }));
vi.mock("../../contexts/AuthContext", () => ({ useAuth: () => ({ user: null, loading: false, ...auth }) }));

import Login from "./Login";

const read = (p) => fs.readFileSync(path.resolve(__dirname, "../../..", p), "utf8");

function renderLogin(url = "/login") {
  return render(
    <MemoryRouter initialEntries={[url]}>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/dashboard" element={<div>DASHBOARD</div>} />
      </Routes>
    </MemoryRouter>
  );
}

describe("v348 — desktop login with an email code", () => {
  beforeEach(() => { cleanup(); apiMock.get.mockReset(); apiMock.post.mockReset(); Object.values(auth).forEach((f) => f.mockReset()); localStorage.clear(); });

  it("'Login with OTP' sends the code and logs in through the app's routes", async () => {
    apiMock.post.mockImplementation((url) => {
      if (url === "auth/login-otp") return Promise.resolve({ data: { success: true } });
      if (url === "auth/login") return Promise.resolve({ data: { token: "T", user: { user_id: "U1", role: "creator", onboarded: true } } });
      return Promise.reject(new Error("unexpected " + url));
    });
    renderLogin();
    fireEvent.change(screen.getByTestId("login-email"), { target: { value: "Riya@Mail.com " } });
    fireEvent.click(screen.getByTestId("login-use-otp"));
    expect(screen.queryByTestId("login-password")).toBeNull();
    fireEvent.click(screen.getByTestId("login-otp-submit"));
    await waitFor(() => expect(apiMock.post).toHaveBeenCalledWith("auth/login-otp", { email: "riya@mail.com", app_role: "creator" }));
    fireEvent.change(await screen.findByTestId("login-otp-code"), { target: { value: "12a3456" } });
    fireEvent.click(screen.getByTestId("login-otp-submit"));
    await waitFor(() => expect(apiMock.post).toHaveBeenCalledWith("auth/login", { email: "riya@mail.com", otp: "123456", app_role: "creator" }));
    expect(await screen.findByText("DASHBOARD")).toBeTruthy();
    expect(localStorage.getItem("ybex_token")).toBe("T");
  });

  it("wrong password → 'Login with OTP instead' sends a code to the same email", async () => {
    auth.login.mockRejectedValue({ response: { data: { code: "INVALID_CREDENTIALS", detail: "Invalid email or password." } } });
    apiMock.post.mockResolvedValue({ data: { success: true } });
    renderLogin("/login?role=brand");
    fireEvent.change(screen.getByTestId("login-email"), { target: { value: "brand@x.com" } });
    fireEvent.change(screen.getByTestId("login-password"), { target: { value: "nope1234" } });
    fireEvent.click(screen.getByTestId("login-submit"));
    fireEvent.click(await screen.findByTestId("login-otp-offer-btn"));
    await waitFor(() => expect(apiMock.post).toHaveBeenCalledWith("auth/login-otp", { email: "brand@x.com", app_role: "brand" }));
    expect(await screen.findByTestId("login-otp-code")).toBeTruthy();
  });

  it("account with no password gets the 'no password yet' line", async () => {
    auth.login.mockRejectedValue({ response: { data: { code: "INVALID_CREDENTIALS", reason: "NO_PASSWORD", detail: "x" } } });
    renderLogin();
    fireEvent.change(screen.getByTestId("login-email"), { target: { value: "otp@x.com" } });
    fireEvent.change(screen.getByTestId("login-password"), { target: { value: "whatever1" } });
    fireEvent.click(screen.getByTestId("login-submit"));
    expect((await screen.findByTestId("login-otp-offer")).textContent).toMatch(/no password yet/);
  });

  it("server: no-password answer keeps the same 401 code; website Google asks to choose an account", () => {
    const s = read("backend/auth_routes.ts");
    expect(s).toContain('code: "INVALID_CREDENTIALS", reason: "NO_PASSWORD"');
    expect(s).toContain('prompt: "select_account consent"');
  });
});
