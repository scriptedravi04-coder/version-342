// v346 front-end fixes (black-box testing at iPhone size): source checks + unit tests for the new helpers.
import { describe, it, expect } from "vitest";
import fs from "fs";
import path from "path";
// @ts-ignore — plain JS module
import { maskContact, hasContact, CONTACT_HIDDEN } from "../src/utils/maskContact.js";
// @ts-ignore — plain JS module
import { initials, firstLetter } from "../src/utils/initials.js";
// @ts-ignore — plain JS module
import { checkHttpUrl } from "../src/utils/httpUrl.js";
// @ts-ignore — plain JS module
import { payableAfterRefund, refundedPart } from "../src/utils/payoutAfterRefund.js";
// @ts-ignore — plain JS module
// @ts-ignore — plain JS module
import { buildBrandApplicationActions } from "../src/components/quickActions/quickActionsData.js";

const ROOT = path.resolve(__dirname, "..");
const read = (f: string) => fs.readFileSync(path.join(ROOT, f), "utf8");

describe("maskContact", () => {
  it("hides phone numbers in every common shape", () => {
    expect(maskContact("Call me 9876543210 ok")).toBe(`Call me ${CONTACT_HIDDEN} ok`);
    expect(maskContact("+91 98765 43210")).toBe(CONTACT_HIDDEN);
    expect(maskContact("+91-98765-43210.")).toBe(`${CONTACT_HIDDEN}.`);
    expect(maskContact("98765-43210")).toBe(CONTACT_HIDDEN);
    expect(maskContact("09876543210")).toBe(CONTACT_HIDDEN);
    expect(maskContact("987 654 3210")).toBe(CONTACT_HIDDEN);
  });
  it("hides number words mixed with digits", () => {
    expect(maskContact("nine 8 7 six 5 4 3 2 1 zero")).toBe(CONTACT_HIDDEN);
    expect(maskContact("whatsapp nine eight seven 6 5 4 3 2 1 0 pls")).toBe(`whatsapp ${CONTACT_HIDDEN} pls`);
  });
  it("hides emails, also spelled out", () => {
    expect(maskContact("mail ravi.k@gmail.com")).toBe(`mail ${CONTACT_HIDDEN}`);
    expect(maskContact("ravi at gmail dot com")).toBe(CONTACT_HIDDEN);
    expect(maskContact("ravi[at]gmail[dot]com")).toBe(CONTACT_HIDDEN);
  });
  it("keeps normal pitch text, prices, counts and dates", () => {
    const keep = [
      "I have 65000 followers, rate 5000 - 10000",
      "budget 15000 - 25000",
      "Posted 2 reels on 12/03/2025",
      "someone gave three reels in 2 days",
      "I love this brand!",
    ];
    for (const s of keep) expect(maskContact(s)).toBe(s);
    expect(hasContact("I love this brand!")).toBe(false);
    expect(hasContact("call 9876543210")).toBe(true);
  });
  it("passes empty values through", () => {
    expect(maskContact("")).toBe("");
    expect(maskContact(null)).toBe(null);
    expect(maskContact(undefined)).toBe(undefined);
  });
  it("quick action cards mask the pitch shown to the brand", () => {
    const cards = buildBrandApplicationActions([
      { c: { campaign_id: "c1", title: "T" }, apps: [{ application_id: "a1", status: "pending", pitch_text: "Ping me on 98765 43210 or a@b.co" }] },
    ]);
    expect(cards[0].note).toBe(`Ping me on ${CONTACT_HIDDEN} or ${CONTACT_HIDDEN}`);
  });
});

describe("initials", () => {
  it("never cuts an emoji in half", () => {
    expect(initials("Glow 🌿 Cosmetics")).toBe("GC");
    expect(initials("🌿 Glow")).toBe("G");
    expect(initials("ravi kumar")).toBe("RK");
    expect(initials("Asha")).toBe("A");
    expect(initials("Asha", { oneWordLetters: 2 })).toBe("AS");
    expect(initials("Ravi Kumar Sharma", { lastWord: true })).toBe("RS");
    expect(initials("🌿 🌸")).toBe("?");
    expect(initials("", { fallback: "B" })).toBe("B");
    expect(initials(null)).toBe("?");
    // no lone surrogate halves anywhere
    expect(/[\uD800-\uDFFF]/.test(initials("Glow 🌿 Cosmetics"))).toBe(false);
    expect(firstLetter("🌿Glow")).toBe("G");
  });
  it("the reported screens use the emoji-safe helper", () => {
    expect(read("src/pages/onboarding/BrandOnboardingMobile.jsx")).toContain("../../utils/initials");
    expect(read("src/pages/brand/BrandHomeMobile.jsx")).toContain("initialsOf(brandName");
    expect(read("src/pages/brand/BrandHomeMobile.jsx")).not.toContain("parts[0][0] + parts[1][0]");
    expect(read("src/pages/creator/CreatorHomeMobile.jsx")).not.toContain('.split(" ").map((n) => n[0])');
    expect(read("src/components/creators/CreatorCard.jsx")).not.toContain(".map(w => w[0])");
    expect(read("src/components/common/PersonPhoto.jsx")).toContain("../../utils/initials");
  });
});

describe("checkHttpUrl", () => {
  it("allows http(s) links and empty, rejects other schemes", () => {
    expect(checkHttpUrl("").ok).toBe(true);
    expect(checkHttpUrl("https://acme.in/shop").url).toBe("https://acme.in/shop");
    expect(checkHttpUrl("acme.in").url).toBe("https://acme.in");
    expect(checkHttpUrl("javascript:alert(1)").ok).toBe(false);
    expect(checkHttpUrl("data:text/html,hi").ok).toBe(false);
    expect(checkHttpUrl("ftp://acme.in").ok).toBe(false);
    expect(checkHttpUrl("not a link").ok).toBe(false);
    expect(checkHttpUrl("hello").ok).toBe(false);
  });
});

describe("payout after a part refund", () => {
  it("payable = max(0, creator net − processed refund)", () => {
    expect(payableAfterRefund({ creator_net_amount: 9000 })).toBe(9000);
    expect(payableAfterRefund({ creator_net_amount: 9000, refund_amount: 3000, refund_status: "PROCESSED" })).toBe(6000);
    expect(payableAfterRefund({ creator_net_amount: 9000, refund_amount: 3000, refund_status: "PENDING" })).toBe(9000);
    expect(payableAfterRefund({ creator_net_amount: 2000, refund_amount: 3000, refund_status: "processed" })).toBe(0);
    expect(refundedPart({ refund_amount: 3000, refund_status: "PROCESSED" })).toBe(3000);
  });
  it("escrow admin uses the payable amount for the UPI link, the release call and the modal", () => {
    const d = read("src/components/admin/EscrowDashboard.jsx");
    expect(d).toContain("creator_net_amount: payableAfterRefund(selectedReleaseTx)");
    expect(d).toContain("const amount = payableAfterRefund(selectedReleaseTx)");
    expect(d).toMatch(/after ₹\{refundedPart\(tx\)/);
    const m = read("src/components/admin/ReleasePayoutModal.jsx");
    expect(m).toContain("const netAmount = payableAfterRefund(tx, fullNetAmount)");
  });
});

describe("no invented numbers", () => {
  // Campaign view / applied numbers for creators stay as Ravi decided in Session 38 (not changed in v346).
  it("landing tickers are product statements, not made-up events", () => {
    for (const f of ["src/components/landing/v2/LandingMobileView.jsx", "src/components/landing/v2/LandingDesktopView.jsx"]) {
      const s = read(f);
      const ticker = s.slice(s.indexOf("const TICKER"), s.indexOf("\n", s.indexOf("const TICKER")));
      expect(ticker).not.toContain("Ananya");
      expect(ticker).not.toContain("Nykaa");
      expect(ticker).not.toContain("₹8,000");
      expect(ticker).not.toContain("₹35,000");
      expect(ticker).toContain("Payment held safely");
      expect(ticker).toContain("email OTP");
    }
  });
  it("creator home has no sample brand banners", () => {
    const s = read("src/pages/creator/CreatorHomeMobile.jsx");
    expect(s).not.toContain("DEFAULT_HERO_BANNERS");
    expect(s).not.toContain("boAt Rockerz");
    expect(s).not.toContain("Nike Pegasus");
    expect(s).not.toContain("Mamaearth Pure");
  });
});

describe("v346 source checks", () => {
  it("Edit Profile loads bio and cover so Save never blanks them", () => {
    const s = read("src/pages/creator/CreatorSettings.jsx");
    expect(s).toMatch(/bio: data\.bio/);
    expect(s).toMatch(/coverImage: data\.cover_image/);
  });
  it("pitch is masked where brands see it", () => {
    expect(read("src/components/chat/mobile/MobileShortlistCards.jsx")).toContain("maskContact(pitch)");
    expect(read("src/components/chat/ShortlistCards.jsx")).toContain("maskContact(m.pitch)");
    expect(read("src/components/campaigns/ApplicantCard.jsx")).toContain("maskContact(a.pitch_text");
    expect(read("src/components/campaigns/mobile/BrandCampaignDetailMobile.jsx")).toContain("maskContact(currentList[playerIndex].pitch_text");
  });
  it("Finish later creators get the normal layout", () => {
    const s = read("src/components/layout/Layout.jsx");
    expect(s).toContain("isFinishLater(user.user_id || user.id)");
    expect(s).toMatch(/isOnboardingUser = user && !isAdminUser && !finishedLater/);
  });
  it("no autosave on the Campaign live screen", () => {
    expect(read("src/components/campaigns/mobile/MobileCampaignCreate.jsx")).toContain('if (currentView === "published") return;');
  });
  it("rates are whole rupees 0…10,00,000", () => {
    const s = read("src/pages/creator/profileScreens/RatesScreen.jsx");
    expect(s).toContain("const RATE_MAX = 1000000");
    expect(s).toContain("disabled={saving || hasRateError}");
  });
  it("quick action sheet: once per session after a dismiss, long titles clamp", () => {
    const s = read("src/components/quickActions/QuickActionsMobile.jsx");
    expect(s).toContain("ybex_quick_actions_dismissed");
    expect(s).toMatch(/const hidden = dismissed \|\|/);
    expect(s).toContain("WebkitLineClamp: 2");
  });
  it("landing content loads under StrictMode", () => {
    for (const f of ["src/components/landing/v2/LandingMobileView.jsx", "src/components/landing/v2/LandingDesktopView.jsx"]) {
      expect(read(f)).toMatch(/componentDidMount\(\) \{\n\s+this\.unmounted = false;/);
    }
  });
  it("input checks: company name, website, UGC link and budget", () => {
    expect(read("src/components/profile/mobile/brand/CompanyDetailsScreen.jsx")).toContain("checkHttpUrl(form?.website");
    expect(read("src/components/Onboarding/BrandOnboardingFlow.jsx")).toContain("website: web.url");
    expect(read("src/pages/brand/BrandSettings.jsx")).toContain("checkHttpUrl(pre.website");
    expect(read("src/pages/brand/brandUgc/BriefStepProduct.jsx")).toContain("checkHttpUrl(postData.sample_content_url");
    const u = read("src/pages/brand/BrandUGCMobile.jsx");
    expect(u).toContain("const budgetError");
    expect(u).not.toContain("setPostData({ ...postData, budget: minBudget })");
  });
  it("signup role, logout, KYC reason", () => {
    expect(read("src/pages/auth/Signup.jsx")).toContain('roleParam === "brand" ? "brand" : "creator"');
    expect(read("src/pages/creator/CreatorSettings.jsx")).toContain('window.location.replace("/login")');
    expect(read("src/components/profile/mobile/BrandProfileMobile.jsx")).toContain('window.location.replace("/login")');
    expect(read("src/pages/creator/CreatorMobileProfile.jsx")).toContain("kycBlockReason");
  });
});
