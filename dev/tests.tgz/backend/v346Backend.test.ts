// v346: backend fixes — deep profile privacy strip, mixed digit+word phone numbers, home-pick rules,
// no sample brand banners, referral over-cap + free-deal spending, part-refund payouts, IST age,
// "—" for non-numeric amounts, deadline copy.
import { describe, it, expect } from "vitest";
import fs from "fs";
import path from "path";
import express from "express";
import { stripPrivateProfileFields } from "./profilePrivacy";
import { checkComprehensiveDisallowedContent, mixedNumberRuns, resetRecentMessageBuffer } from "./contactSecurityFilter";
import { setupCreatorHomePicks } from "./creatorHomePicks";
import { rewardBlocks, freeDealsLeft, normaliseConfig, referralSummary, referralData } from "./referralProgram";
import { readyRows } from "./creatorPayoutRequests";
import { ageFromDob, isUnder18 } from "../src/lib/age.js";
import { formatINROrDash } from "../src/utils/safeFormat.js";
import { formatTimeLeft, formatDeadlineTime, buildReminderCopy } from "./services/ugcDeadlineService";

const DAY = 86400e3;
const iso = (ms: number) => new Date(ms).toISOString();
const read = (p: string) => fs.readFileSync(path.resolve(__dirname, "..", p), "utf8");

// ------------------------------------------------------------------ 1. profile privacy
describe("v346 fix 1: private fields stripped at every depth", () => {
  it("removes nested phone / email / upi / bank / address, keeps public rates", () => {
    const out: any = stripPrivateProfileFields({
      name: "Asha", email: "a@x.com",
      rate_card: {
        reel: 5000, story: 1500, dob: "2000-01-01",
        extras: { phone: "9876543210", whatsapp_number: "9876543210", note: "fast", combo: 9000, upi_id: "a@upi" },
        packages: [{ title: "Pack", price: 12000, contact_email: "x@y.com", bank_account_number: "1234", address: "Jaipur" }],
      },
      socials: [{ platform: "instagram", followers: 10000, personal_phone: "1" }],
    });
    expect(out.email).toBeUndefined();
    expect(out.rate_card.reel).toBe(5000);
    expect(out.rate_card.story).toBe(1500);
    expect(out.rate_card.dob).toBeUndefined();
    expect(out.rate_card.extras).toEqual({ note: "fast", combo: 9000 });
    expect(out.rate_card.packages).toEqual([{ title: "Pack", price: 12000 }]);
    expect(out.socials).toEqual([{ platform: "instagram", followers: 10000 }]);
    expect(JSON.stringify(out)).not.toMatch(/9876543210|a@upi|x@y\.com|Jaipur/);
  });
  it("survives circular objects and keeps primitives / nulls", () => {
    const a: any = { name: "x", rate_card: null, tags: ["a", "b"] };
    a.self = a;
    const out: any = stripPrivateProfileFields(a);
    expect(out.name).toBe("x");
    expect(out.rate_card).toBeNull();
    expect(out.tags).toEqual(["a", "b"]);
  });
});

// ------------------------------------------------------------------ 2. contact filter
describe("v346 fix 2: mixed digit + word phone numbers", () => {
  const blocked = (t: string) => { resetRecentMessageBuffer(); return checkComprehensiveDisallowedContent(t).blocked; };
  it("blocks words + digits mixed", () => {
    expect(blocked("nine eight seven six five 43210")).toBe(true);
    expect(blocked("9876five43210")).toBe(true);
    expect(blocked("call 98765 four three two one zero")).toBe(true);
    expect(blocked("nau aath 76543210")).toBe(true);
    expect(blocked("98 double 7 six 543210")).toBe(true);
  });
  it("normal text still passes", () => {
    for (const t of [
      "5 videos for 15000", "budget is 15000 do 2 reels", "deliver on 12-05-2026", "price 9000 one reel", "rate 9000 do 50000",
      "I can do 3 reels and one story for 25000", "Shoot at 5 pm, one take", "2 reels + 1 story = 18000",
    ]) expect(blocked(t), t).toBe(false);
  });
  it("mixedNumberRuns only returns real mixes", () => {
    expect(mixedNumberRuns("nine eight seven six five 43210")).toEqual(["9876543210"]);
    expect(mixedNumberRuns("9876543210")).toEqual([]);
    expect(mixedNumberRuns("nine eight seven")).toEqual([]);
    expect(mixedNumberRuns("9000 do 50000")).toEqual([]); // one everyday Hinglish word is not enough
  });
});

// ------------------------------------------------------------------ 3. home picks
async function serve(app: express.Express, fn: (base: string) => Promise<void>) {
  const srv = app.listen(0);
  await new Promise((r) => srv.once("listening", r));
  const port = (srv.address() as any).port;
  try { await fn(`http://127.0.0.1:${port}`); } finally { srv.close(); }
}
function homeApp(db: any, user: any) {
  const app = express(); app.use(express.json());
  const router = express.Router();
  setupCreatorHomePicks(router, { supabase: null, privilegedSupabase: null, getDb: () => db, saveDb: () => {}, parseAuthUser: async () => user });
  app.use("/api", router);
  return app;
}
describe("v346 fix 3: creator home picks", () => {
  it("ticked rows: only showable creators, never the viewer", async () => {
    const db = { creator_profiles: [
      { user_id: "me", name: "Me Creator", show_on_creator_home: true, picture: "https://p/1" },
      { user_id: "ok", name: "Asha Rao", show_on_creator_home: true, picture: "https://p/2" },
      { user_id: "pend", name: "Pending One", profile_status: "pending", show_on_creator_home: true },
      { user_id: "tst", name: "test user", show_on_creator_home: true },
    ] };
    await serve(homeApp(db, { user_id: "me", role: "creator" }), async (base) => {
      const d = await (await fetch(base + "/api/creators/home-picks")).json();
      expect(d.picks.map((p: any) => p.id)).toEqual(["ok"]);
    });
  });
  it("admin tick: saved, with a warning when not approved / no photo", async () => {
    const db: any = { creator_profiles: [
      { user_id: "nophoto", name: "Asha Rao" },
      { user_id: "pend", name: "Ravi K", profile_status: "pending", picture: "https://p" },
      { user_id: "good", name: "Good One", picture: "https://p" },
    ] };
    const post = (base: string, id: string, on: boolean) => fetch(`${base}/api/admin/creators/${id}/home-pick`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ on }) }).then((r) => r.json());
    await serve(homeApp(db, { user_id: "a", role: "admin" }), async (base) => {
      const w = "Shows only after the creator is approved and has a profile photo.";
      expect(await post(base, "nophoto", true)).toEqual({ ok: true, on: true, warning: w });
      expect(await post(base, "pend", true)).toEqual({ ok: true, on: true, warning: w });
      expect(await post(base, "good", true)).toEqual({ ok: true, on: true });
      expect(await post(base, "nophoto", false)).toEqual({ ok: true, on: false });
    });
    expect(db.creator_profiles.find((p: any) => p.user_id === "pend").show_on_creator_home).toBe(true);
  });
  it("AdminUsersTab shows the warning with a toast", () => {
    const s = read("src/components/admin/AdminUsersTab.jsx");
    expect(s).toMatch(/res\?\.data\?\.warning/);
    expect(s).toMatch(/toast\.warning\(/);
  });
});

// ------------------------------------------------------------------ 4. banners
describe("v346 fix 4: no sample brand banners", () => {
  it("initial store has no boAt / Nike banners and never refills them", () => {
    const s = read("backend/server.ts");
    expect(s).not.toContain("boAt Rockerz");
    expect(s).not.toContain("Nike Pegasus");
    expect(s).toMatch(/banners: \[\],/);
    expect(s).not.toContain("parsed.banners = getInitialDbState().banners");
  });
});

// ------------------------------------------------------------------ 5. referral
describe("v346 fix 5: referral over-cap + free-deal spending", () => {
  const cfg = normaliseConfig({});
  const refs = (n: number, at: number, status = "joined", tag = "x") =>
    Array.from({ length: n }, (_, i) => ({ id: `${tag}${at}_${i}`, referrer_id: "u1", referred_id: `${tag}_${i}`, status, created_at: iso(at + i * 1000) }));
  it("over_cap joins do not count", () => {
    expect(rewardBlocks(refs(3, Date.now(), "over_cap"), cfg).blocks.length).toBe(0);
    expect(rewardBlocks([...refs(2, Date.now()), ...refs(1, Date.now(), "OVER_CAP", "y")], cfg).joined).toBe(2);
  });
  it("inviteRewards also skips over_cap", () => {
    expect(read("backend/inviteRewards.ts")).toMatch(/\["rejected", "over_cap"\]/);
  });
  it("each use is spent on the block live at the time", () => {
    const now = Date.now();
    const blocks = [
      { completed_at: iso(now - 400 * DAY), free_deals: 2, expires_at: iso(now - 220 * DAY), featured_until: "" },
      { completed_at: iso(now - 30 * DAY), free_deals: 2, expires_at: iso(now + 150 * DAY), featured_until: "" },
    ];
    expect(freeDealsLeft(blocks, [{ created_at: iso(now - 10 * DAY) }], now).left).toBe(1);
    expect(freeDealsLeft(blocks, [{ created_at: iso(now - 300 * DAY) }], now).left).toBe(2); // used on the old block
    expect(freeDealsLeft(blocks, [{ created_at: null }], now).left).toBe(1); // undated → live block (cautious)
    expect(freeDealsLeft(blocks, 1, now).left).toBe(2); // plain count keeps the old behaviour
    expect(freeDealsLeft(blocks, Infinity, now).left).toBe(0);
  });
  it("referralSummary charges the live block (local store)", async () => {
    const t = Date.now();
    const db: any = { referrals: [...refs(3, t - 400 * DAY, "joined", "a"), ...refs(3, t - 30 * DAY, "joined", "b")], referral_reward_uses: [{ id: "u", user_id: "u1", created_at: iso(t - 10 * DAY) }] };
    const s = await referralSummary({ supabase: null, privilegedSupabase: null, getDb: () => db }, "u1");
    expect(s.fd.left).toBe(1);
  });
  it("fails closed when the uses can't be read", async () => {
    const t = Date.now();
    const db: any = { referrals: refs(3, t - 5 * DAY) };
    const q: any = {
      select: () => q, eq: () => q, limit: () => q, order: () => q, in: () => q, ilike: () => q,
      maybeSingle: async () => ({ data: null, error: null }),
      then: (r: any) => r({ data: null, error: { message: "down" } }),
    };
    const client = { from: (table: string) => (table === "referrals" ? { select: () => ({ eq: async () => ({ data: db.referrals, error: null }) }) } : q) };
    const deps = { supabase: client, privilegedSupabase: client, getDb: () => ({}) };
    expect(await referralData(deps).freeDealUseList("u1")).toBeNull();
    expect(await referralData(deps).freeDealUses("u1")).toBe(Infinity);
    const s = await referralSummary(deps, "u1");
    expect(s.rb.blocks.length).toBe(1);
    expect(s.fd.left).toBe(0);
  });
});

// ------------------------------------------------------------------ 6. payout requests
describe("v346 fix 6: part refund doesn't block the rest of the payout", () => {
  const base = { deal_id: "d1", status: "SUCCESS", payout_status: "RELEASED", gross_amount: 10000 };
  it("part refund processed → still ready", () => {
    expect(readyRows([{ id: "a", ...base, refund_amount: 2000, refund_status: "PROCESSED" }]).length).toBe(1);
  });
  it("full / in-progress refunds still blocked", () => {
    expect(readyRows([{ id: "b", ...base, refund_amount: 10000, refund_status: "PROCESSED" }]).length).toBe(0);
    expect(readyRows([{ id: "c", ...base, refund_status: "PENDING", refund_amount: 2000 }]).length).toBe(0);
    expect(readyRows([{ id: "d", ...base, status: "REFUNDED" }]).length).toBe(0);
    expect(readyRows([{ id: "e", ...base, status: "REFUND_PENDING" }]).length).toBe(0);
    expect(readyRows([{ id: "f", ...base, refund_amount: 10000 }]).length).toBe(0);
  });
});

// ------------------------------------------------------------------ 7. small helpers
describe("v346 fix 7: IST age, dash for unknown amounts, deadline copy", () => {
  it("age by the IST date", () => {
    // 18th birthday 2026-10-19; 00:30 IST = 2026-10-18T19:00Z
    const now = new Date("2026-10-18T19:00:00Z");
    expect(ageFromDob(19, 10, 2008, now)).toBe(18);
    expect(isUnder18(19, 10, 2008, now)).toBe(false);
    expect(ageFromDob(19, 10, 2008, new Date("2026-10-18T18:00:00Z"))).toBe(17); // 23:30 IST on the 18th
  });
  it("formatINROrDash", () => {
    expect(formatINROrDash("N/A")).toBe("—");
    expect(formatINROrDash("TBD")).toBe("—");
    expect(formatINROrDash({} as any)).toBe("—");
    expect(formatINROrDash("₹1,500")).toBe("₹1,500");
    expect(formatINROrDash(0)).toBe("₹0");
  });
  it("deadline copy", () => {
    expect(formatTimeLeft(30_000)).toBe("1 minute");
    expect(formatTimeLeft(NaN)).toBe("0 hours");
    expect(formatDeadlineTime("not a date")).toBe("the deadline");
    const c = buildReminderCopy({ reminderIndex: 2, order: { id: "o", internal_deadline: "garbage" } as any, brief: { title: "B" } as any, brand: {}, creator: { name: "A" } });
    expect(JSON.stringify(c)).not.toContain("Invalid Date");
  });
});
