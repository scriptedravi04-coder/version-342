// v377 (Ravi's approved round-3 email design): lighter band, darker footer, illustrations on happy emails only.
import { describe, it, expect } from "vitest";
import express from "express";
import type { AddressInfo } from "net";
import { buildEmailHtml } from "./helpers";
import { activityHero } from "./notificationService";
import { EMAIL_ART, setupEmailArtRoutes } from "./emailArt";

describe("v377 · email look", () => {
  it("lighter purple band, readable footer, ybexmedia.in link", () => {
    const h = buildEmailHtml({ title: "Hi", paragraphs: ["x"] });
    expect(h).toContain("linear-gradient(160deg,#5B21B6 0%,#7C3AED 55%,#A78BFA 100%)");
    expect(h).not.toContain("#3B1A7A");
    expect(h).toContain("color:#4F4966");
    expect(h).toContain('href="https://ybexmedia.in"');
  });
  it("hero picture replaces the icon tile; no hero = icon tile as before", () => {
    const withHero = buildEmailHtml({ title: "You're live", hero: "phone", icon: "✓" });
    expect(withHero).toMatch(/\/api\/email-art\/phone\.png/);
    expect(withHero).not.toContain("width:58px;height:58px");
    const plain = buildEmailHtml({ title: "Code", icon: "🔐" });
    expect(plain).toContain("width:58px;height:58px");
    expect(plain).not.toContain("email-art");
  });
  it("pictures only on approvals / go-lives, never on money, deadlines or rejections", () => {
    expect(activityHero("PROFILE_APPROVED")).toBe("phone");
    expect(activityHero("CAMPAIGN_LIVE")).toBe("duo");
    for (const t of ["PAYOUT_RELEASED", "REFUND_PROCESSED", "KYC_REJECTED", "CAMPAIGN_REJECTED", "PAYMENT_FUNDED", "REMINDER", "WARNING", "REVISION_REQUESTED"]) expect(activityHero(t)).toBeUndefined();
  });
  it("GET /api/email-art/<name>.png serves real PNGs, 404 for unknown", async () => {
    const app = express(); const r = express.Router(); setupEmailArtRoutes(r); app.use("/api", r);
    const srv: any = await new Promise((ok) => { const s = app.listen(0, () => ok(s)); });
    const base = `http://127.0.0.1:${(srv.address() as AddressInfo).port}/api/email-art/`;
    try {
      for (const n of Object.keys(EMAIL_ART)) {
        const res = await fetch(base + n + ".png");
        expect(res.status).toBe(200);
        expect(res.headers.get("content-type")).toBe("image/png");
        const b = Buffer.from(await res.arrayBuffer());
        expect(b.subarray(1, 4).toString()).toBe("PNG");
      }
      expect((await fetch(base + "nope.png")).status).toBe(404);
    } finally { srv.close(); }
  });
});
