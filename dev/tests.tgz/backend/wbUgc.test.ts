// White-box tests: UGC slots (claim race), order cancel rules (client + server copies), delivery terms,
// IST deadline helpers, KYC status, order sorting, campaign display stats.
// Tests marked it.fails document a real bug in the CURRENT code (see the "BUG:" comment above each).
import { describe, it, expect } from "vitest";
import { createUgcSlots } from "./ugcSlots";
import {
  CREATOR_CANCEL_REASONS, CREATOR_CANCEL_GRACE_MS, BRAND_ORDER_CANCEL_WAIT_MS, orderTimerStartMs, creatorCancelInfo, brandCancelInfo, formatWait,
} from "../src/utils/ugcOrderCancel";
import { DELIVERY_OPTIONS, deliveryHoursOf, orderWindowHours, UGC_REVISION_LIMIT } from "../src/utils/ugcTerms";
import { normalizeDeliveryHours, isMissingColumnError, isBriefFullyDelivered, UGC_REVISION_LIMIT as SERVER_REVISION_LIMIT, DEFAULT_DELIVERY_HOURS } from "./ugcTerms";
import * as svc from "./services/ugcDeadlineService";
import { normalizeKycStatus } from "../src/utils/kycStatus";
import { getCampaignStats, getCampaignAvatars } from "../src/utils/campaignStats";
import { isClosedOrder, compareOrdersForWork, sortOrdersForWork } from "../src/utils/orderSort";

const H = 3600000;

// ---------------------------------------------------------------- ugcSlots with a fake Supabase
function fakeBriefs(rows: Record<string, any>, opts: { conflicts?: number; updateError?: any; selectThrows?: boolean } = {}) {
  let conflicts = opts.conflicts || 0;
  const log: any[] = [];
  const client = {
    log,
    from: () => {
      let mode = "select"; let patch: any = null; const filters: any[] = [];
      const q: any = {
        select: () => q,
        update: (p: any) => { mode = "update"; patch = p; return q; },
        eq: (c: string, v: any) => { filters.push(["eq", c, v]); if (mode === "update" && c === "claimed_count") return thenSelect(); return q; },
        is: (c: string, v: any) => { filters.push(["is", c, v]); return thenSelect(); },
        maybeSingle: async () => {
          if (opts.selectThrows) throw new Error("db down");
          const id = filters.find((f) => f[1] === "id")?.[2];
          return { data: rows[id] ? { ...rows[id] } : null, error: null };
        },
      };
      const thenSelect = () => ({
        select: async () => {
          log.push({ patch, filters: [...filters] });
          if (opts.updateError) return { data: null, error: opts.updateError };
          if (conflicts > 0) { conflicts--; return { data: [], error: null }; }
          const id = filters.find((f) => f[1] === "id")?.[2];
          const cas = filters.find((f) => f[1] === "claimed_count");
          const cur = rows[id]?.claimed_count;
          const match = cas[0] === "is" ? cur == null : cur === cas[2];
          if (!rows[id] || !match) return { data: [], error: null };
          Object.assign(rows[id], patch);
          return { data: [{ id }], error: null };
        },
      });
      return q;
    },
  };
  return client;
}
const mkSlots = (client: any, db: any = { ugc_briefs: [] }) => createUgcSlots({ getClient: () => client, getDb: () => db, saveDb: () => {} });

describe("ugcSlots.reserveBriefSlot / releaseBriefSlot", () => {
  it("takes slots up to max_creators, marks CLAIMED when full, then refuses", async () => {
    const rows: any = { b1: { claimed_count: null, max_creators: 2, status: "OPEN" } };
    const s = mkSlots(fakeBriefs(rows));
    expect(await s.reserveBriefSlot({ id: "b1" }, "c1")).toEqual({ ok: true, previousCount: 0 });
    expect(rows.b1).toMatchObject({ claimed_count: 1, status: "OPEN" });
    expect((await s.reserveBriefSlot({ id: "b1" }, "c2")).ok).toBe(true);
    expect(rows.b1).toMatchObject({ claimed_count: 2, status: "CLAIMED" });
    expect((await s.reserveBriefSlot({ id: "b1" }, "c3")).code).toBe("BRIEF_FULL");
  });

  it("a double tap by the same creator is refused while the first claim runs; finishBriefClaim clears it", async () => {
    const rows: any = { b1: { claimed_count: 0, max_creators: 5 } };
    const s = mkSlots(fakeBriefs(rows));
    expect((await s.reserveBriefSlot({ id: "b1" }, "c1")).ok).toBe(true);
    expect((await s.reserveBriefSlot({ id: "b1" }, "c1")).code).toBe("CLAIM_IN_PROGRESS");
    s.finishBriefClaim("b1", "c1");
    expect((await s.reserveBriefSlot({ id: "b1" }, "c1")).ok).toBe(true);
  });

  it("compare-and-set: retries after a lost race, gives up after 5 with CLAIM_CONFLICT", async () => {
    const rows: any = { b1: { claimed_count: 0, max_creators: 1 } };
    expect((await mkSlots(fakeBriefs(rows, { conflicts: 2 })).reserveBriefSlot({ id: "b1" }, "c1")).ok).toBe(true);
    const rows2: any = { b1: { claimed_count: 0, max_creators: 1 } };
    const r = await mkSlots(fakeBriefs(rows2, { conflicts: 99 })).reserveBriefSlot({ id: "b1" }, "c1");
    expect(r.code).toBe("CLAIM_CONFLICT");
    expect(rows2.b1.claimed_count).toBe(0);
  });

  it("update error → SLOT_ERROR and the creator may try again at once", async () => {
    const s = mkSlots(fakeBriefs({ b1: { claimed_count: 0, max_creators: 1 } }, { updateError: { message: "x" } }));
    expect((await s.reserveBriefSlot({ id: "b1" }, "c1")).code).toBe("SLOT_ERROR");
    expect((await s.reserveBriefSlot({ id: "b1" }, "c1")).code).toBe("SLOT_ERROR"); // not CLAIM_IN_PROGRESS
  });

  it("max_creators missing / 0 / junk → one slot; string counts are numbers", async () => {
    const rows: any = { b1: { claimed_count: "0", max_creators: "abc" } };
    const s = mkSlots(fakeBriefs(rows));
    // "0" !== 0 for the CAS filter: the fake only matches the exact stored value
    expect((await s.reserveBriefSlot({ id: "b1" }, "c1")).ok).toBe(true);
    expect((await s.reserveBriefSlot({ id: "b1" }, "c2")).code).toBe("BRIEF_FULL");
  });

  it("local store fallback (no Supabase): not found → 404; full → refused", async () => {
    const db = { ugc_briefs: [{ id: "b9", claimed_count: 1, max_creators: 1 }] };
    const s = mkSlots(null, db);
    expect((await s.reserveBriefSlot({ id: "nope" }, "c1")).status).toBe(404);
    expect((await s.reserveBriefSlot({ id: "b9" }, "c1")).code).toBe("BRIEF_FULL");
    expect((await s.reserveBriefSlot(null, "c1")).status).toBe(404);
  });

  it("release: CLAIMED reopens, a closed brief stays closed, never below 0", async () => {
    const rows: any = { a: { claimed_count: 2, max_creators: 2, status: "CLAIMED" }, b: { claimed_count: 1, max_creators: 1, status: "CLOSED" }, z: { claimed_count: 0, max_creators: 1, status: "OPEN" } };
    const s = mkSlots(fakeBriefs(rows));
    await s.releaseBriefSlot("a", "c1");
    await s.releaseBriefSlot("b");
    await s.releaseBriefSlot("z");
    await s.releaseBriefSlot("");
    expect(rows.a).toMatchObject({ claimed_count: 1, status: "OPEN" });
    expect(rows.b).toMatchObject({ claimed_count: 0, status: "CLOSED" });
    expect(rows.z.claimed_count).toBe(0);
    const db = { ugc_briefs: [{ id: "l", claimed_count: 0, max_creators: 1, status: "OPEN" }] };
    await mkSlots(null, db).releaseBriefSlot("l");
    expect(db.ugc_briefs[0].claimed_count).toBe(0);
  });
});

// ---------------------------------------------------------------- terms
describe("ugcTerms (client + server agree)", () => {
  it("delivery hours: only 24 / 48 / 72; else the fallback", () => {
    expect(DELIVERY_OPTIONS.map((o) => o.hours)).toEqual([24, 48, 72]);
    expect(deliveryHoursOf("48")).toBe(48);
    expect(deliveryHoursOf(36)).toBe(48);
    expect(deliveryHoursOf(null, 24)).toBe(24);
    expect(normalizeDeliveryHours("72")).toBe(72);
    expect(normalizeDeliveryHours(0)).toBe(DEFAULT_DELIVERY_HOURS);
    expect(UGC_REVISION_LIMIT).toBe(SERVER_REVISION_LIMIT);
  });
  it("orderWindowHours from the order's own dates", () => {
    const c = "2026-10-19T00:00:00Z";
    expect(orderWindowHours({ created_at: c, deadline: "2026-10-21T00:00:00Z" })).toBe(48);
    expect(orderWindowHours({ created_at: c, internal_deadline: "2026-10-19T10:20:00Z" })).toBe(10);
    expect(orderWindowHours({ created_at: c, deadline: c })).toBe(24); // end <= start
    expect(orderWindowHours({ created_at: c, deadline: "2026-10-19T00:10:00Z" })).toBe(1); // never 0
    expect(orderWindowHours(null, 7)).toBe(7);
  });
  it("isMissingColumnError / isBriefFullyDelivered", () => {
    expect(isMissingColumnError({ code: "PGRST204", message: "Could not find the 'delivery_hours' column" }, "delivery_hours")).toBe(true);
    expect(isMissingColumnError({ code: "42703", message: "other_col" }, "delivery_hours")).toBe(false);
    expect(isMissingColumnError(null, "x")).toBe(false);
    expect(isBriefFullyDelivered(1, null)).toBe(true);
    expect(isBriefFullyDelivered(1, "3")).toBe(false);
    expect(isBriefFullyDelivered(3, 3)).toBe(true);
    expect(isBriefFullyDelivered(0, 0)).toBe(false);
  });
});

// ---------------------------------------------------------------- cancel rules
describe("ugcOrderCancel (client copy) vs ugcDeadlineService (server)", () => {
  const T = Date.parse("2026-10-19T00:00:00Z");
  const order = { id: "o1", created_at: new Date(T).toISOString(), internal_deadline: new Date(T + 48 * H).toISOString(), brief: { delivery_hours: 48 }, agreement_signed_creator: true };

  it("same reasons, grace and wait on both sides", () => {
    expect([...svc.CREATOR_CANCEL_REASONS]).toEqual(CREATOR_CANCEL_REASONS);
    expect(svc.CREATOR_CANCEL_GRACE_MS).toBe(CREATOR_CANCEL_GRACE_MS);
    expect(svc.BRAND_ORDER_CANCEL_WAIT_MS).toBe(BRAND_ORDER_CANCEL_WAIT_MS);
  });

  it("timer start = deadline - delivery window (client and server agree)", () => {
    expect(orderTimerStartMs(order)).toBe(T);
    expect(svc.orderTimerStartMs(order, 48)).toBe(T);
    expect(orderTimerStartMs({ created_at: "2026-10-19T05:00:00Z" })).toBe(Date.parse("2026-10-19T05:00:00Z"));
    expect(orderTimerStartMs({})).toBeNull();
    expect(svc.orderTimerStartMs({}, 24)).toBeNull();
    expect(svc.orderTimerStartMs({ internal_deadline: new Date(T + 24 * H).toISOString() }, "junk")).toBe(T);
  });

  it("creator: first hour after the timer starts doesn't count; boundary at exactly 1h counts", () => {
    const g = creatorCancelInfo(order, T + 30 * 60000);
    expect(g).toEqual({ allowed: true, counts: false, graceLeftMs: 30 * 60000 });
    expect(creatorCancelInfo(order, T + H).counts).toBe(true);
    expect(svc.creatorCancelReasonToken(order, 48, T + 30 * 60000)).toBe("CREATOR_CANCELLED_GRACE");
    expect(svc.creatorCancelReasonToken(order, 48, T + H)).toBe("CREATOR_CANCELLED");
  });

  it("creator: never signed → free cancel; undefined signature = signed", () => {
    expect(creatorCancelInfo({ ...order, agreement_signed_creator: null }, T + 10 * H)).toEqual({ allowed: true, counts: false, graceLeftMs: 0 });
    expect(svc.creatorCancelReasonToken({ agreement_signed_creator: false }, 24, 0)).toBe("CREATOR_CANCELLED_UNSIGNED");
    const { agreement_signed_creator, ...noFlag } = order;
    void agreement_signed_creator;
    expect(creatorCancelInfo(noFlag, T + 10 * H).counts).toBe(true);
  });

  it("creator: no cancel once a draft exists or the order is closed (any case); no id → not allowed", () => {
    expect(creatorCancelInfo({ ...order, video_url: "v" }).allowed).toBe(false);
    expect(creatorCancelInfo({ ...order, status: "in_review" }).allowed).toBe(false);
    expect(creatorCancelInfo({ ...order, status: "refunded" }).allowed).toBe(false);
    expect(creatorCancelInfo({ raw: { ...order, status: "Cancelled" } }).allowed).toBe(false);
    expect(creatorCancelInfo({ status: "ACCEPTED" }).allowed).toBe(false);
    expect(creatorCancelInfo(null).allowed).toBe(false);
  });

  it("brand: 24h after the timer starts, not a ms earlier; draft blocks; unknown start never allowed", () => {
    expect(brandCancelInfo(order, T + 24 * H - 1)).toMatchObject({ allowed: false, why: "TOO_EARLY", allowedAtMs: T + 24 * H });
    expect(brandCancelInfo(order, T + 24 * H)).toEqual({ show: true, allowed: true });
    expect(svc.brandCanCancelOrderAtMs(order, 48)).toBe(T + 24 * H);
    expect(brandCancelInfo({ ...order, delivered_at: "x" }, T + 99 * H)).toMatchObject({ allowed: false, why: "DRAFT" });
    expect(brandCancelInfo({ ...order, status: "completed" })).toEqual({ show: false });
    expect(brandCancelInfo({ id: "x" }, T)).toMatchObject({ allowed: false, allowedAtMs: null });
  });

  it("formatWait rounds up to minutes", () => {
    expect(formatWait(-5)).toBe("0 min");
    expect(formatWait(1)).toBe("1 min");
    expect(formatWait(60 * 60000)).toBe("1h");
    expect(formatWait(61 * 60000 + 1)).toBe("1h 2m");
  });
});

// ---------------------------------------------------------------- IST helpers (server)
describe("ugcDeadlineService IST helpers", () => {
  it("quiet hours are 22:00–07:59 IST regardless of server time zone", () => {
    expect(svc.isQuietHours(new Date("2026-10-19T16:29:59Z"))).toBe(false); // 21:59:59 IST
    expect(svc.isQuietHours(new Date("2026-10-19T16:30:00Z"))).toBe(true); // 22:00 IST
    expect(svc.isQuietHours(new Date("2026-10-19T18:30:00Z"))).toBe(true); // IST midnight
    expect(svc.isQuietHours(new Date("2026-10-20T02:29:59Z"))).toBe(true); // 07:59:59 IST
    expect(svc.isQuietHours(new Date("2026-10-20T02:30:00Z"))).toBe(false); // 08:00 IST
  });
  it("getIstDate: wall-clock IST (UTC+5:30) across the IST midnight", () => {
    const d = svc.getIstDate(new Date("2026-10-19T18:29:00Z"));
    expect([d.getHours(), d.getMinutes(), d.getDate()]).toEqual([23, 59, 19]);
    const e = svc.getIstDate(new Date("2026-10-19T18:30:00Z"));
    expect([e.getHours(), e.getDate()]).toEqual([0, 20]);
  });
  it("draft / closed predicates", () => {
    expect(svc.hasUgcFirstDraft({ status: "awaiting_live_link" })).toBe(true);
    expect(svc.hasUgcFirstDraft({ drive_url: "d" })).toBe(true);
    expect(svc.hasUgcFirstDraft({ status: "ACCEPTED" })).toBe(false);
    expect(svc.hasUgcFirstDraft(null)).toBe(false);
    expect(svc.isOrderClosed(null)).toBe(true);
    expect(svc.isOrderClosed({ status: "expired" })).toBe(true);
    expect(svc.isOrderClosed({ status: "REVISION_REQ" })).toBe(false);
  });
  it("formatTimeLeft", () => {
    expect(svc.formatTimeLeft(0)).toBe("0 hours");
    expect(svc.formatTimeLeft(-1)).toBe("0 hours");
    expect(svc.formatTimeLeft(H)).toBe("1 hour");
    expect(svc.formatTimeLeft(2.5 * H)).toBe("2 hours 30m");
    expect(svc.formatTimeLeft(3.5 * H)).toBe("3 hours");
    expect(svc.formatTimeLeft(60000)).toBe("1 minute");
    expect(svc.formatTimeLeft(59 * 60000)).toBe("59 minutes");
  });
  // BUG (copy, low): under one minute left the reminder says "1 minutes" (value is clamped to 1 but the plural
  // check uses the unclamped 0). Fix (ugcDeadlineService.ts:121): const m = Math.max(1, minutes); use m twice.
  // v346: FIXED — this used to be it.fails (bug above is fixed in v346).
  it("formatTimeLeft: 30 seconds reads '1 minute'", () => {
    expect(svc.formatTimeLeft(30000)).toBe("1 minute");
  });
  it("formatDeadlineTime: empty → 'the deadline'; today / tomorrow in IST", () => {
    expect(svc.formatDeadlineTime("")).toBe("the deadline");
    const soon = new Date(Date.now() + 60000).toISOString();
    expect(svc.formatDeadlineTime(soon)).toMatch(/today|tomorrow/);
  });
  // BUG (copy, low): a bad deadline string produces "Invalid Date Invalid Date" in the WhatsApp/email reminder
  // (new Date() doesn't throw, so the catch never runs). Fix (ugcDeadlineService.ts:127): if isNaN(d.getTime()) return "the deadline".
  // v346: FIXED — this used to be it.fails (bug above is fixed in v346).
  it("formatDeadlineTime: an unparsable date never prints 'Invalid Date'", () => {
    expect(svc.formatDeadlineTime("not-a-date")).not.toContain("Invalid Date");
  });
  it("reminderSpacing: 24h → 6h then every 3h; longer windows scale; junk → 24h", () => {
    expect(svc.reminderSpacing(24 * H)).toEqual({ firstMs: 6 * H, everyMs: 3 * H });
    expect(svc.reminderSpacing(72 * H)).toEqual({ firstMs: 18 * H, everyMs: 9 * H });
    expect(svc.reminderSpacing(NaN)).toEqual({ firstMs: 6 * H, everyMs: 3 * H });
    expect(svc.reminderSpacing(-1)).toEqual({ firstMs: 6 * H, everyMs: 3 * H });
  });
  it("escapeHtml", () => {
    expect(svc.escapeHtml(`<a href="x">'&'</a>`)).toBe("&lt;a href=&quot;x&quot;&gt;&#39;&amp;&#39;&lt;/a&gt;");
    expect(svc.escapeHtml(null)).toBe("");
  });
});

// ---------------------------------------------------------------- misc display logic
describe("kycStatus.normalizeKycStatus", () => {
  it("maps every spelling, any case; nothing → NONE; anything else → PENDING", () => {
    expect(normalizeKycStatus(null)).toBe("NONE");
    expect(normalizeKycStatus({})).toBe("NONE");
    expect(normalizeKycStatus({ status: "verified" })).toBe("APPROVED");
    expect(normalizeKycStatus({ kyc_status: "Denied" })).toBe("REJECTED");
    expect(normalizeKycStatus({ status: "not_submitted" })).toBe("NONE");
    expect(normalizeKycStatus({ status: "under_review" })).toBe("PENDING");
    expect(normalizeKycStatus({ status: " approved " })).toBe("PENDING"); // documented: no trim
  });
});

describe("orderSort", () => {
  it("open before closed; nearest deadline first; no deadline after; closed newest first", () => {
    const list = [
      { id: "c1", status: "COMPLETED", updated_at: "2026-10-01" },
      { id: "o3", status: "IN_PROGRESS" },
      { id: "o2", status: "IN_PROGRESS", deadline: "2026-10-25" },
      { id: "c2", stage: "refunded", updated_at: "2026-10-10" },
      { id: "o1", status: "DISPUTED", deadline: "2026-10-20" },
    ];
    expect(sortOrdersForWork(list).map((o) => o.id)).toEqual(["o1", "o2", "o3", "c2", "c1"]);
    expect(sortOrdersForWork(null as any)).toEqual([]);
    expect(isClosedOrder({ raw: { status: "Expired" } })).toBe(true);
    expect(compareOrdersForWork({ id: "a" }, { id: "b" })).toBeGreaterThan(0); // id desc tie-break
  });
});

describe("campaignStats (display only)", () => {
  it("is deterministic per campaign and stays in its documented ranges", () => {
    const c = { campaign_id: "abc" };
    expect(getCampaignStats(c)).toEqual(getCampaignStats({ ...c }));
    expect(getCampaignStats(null)).toEqual({ views: 12, applied: 3 });
    for (const id of ["a", "b", "c", "d", "zz", "campaign-123"]) {
      const s = getCampaignStats({ id });
      expect(s.applied).toBeGreaterThanOrEqual(2);
      expect(s.applied).toBeLessThanOrEqual(5);
      expect(s.views).toBeGreaterThan(s.applied);
    }
  });
  it("documented: real applicant counts above 8 are hidden (capped at 8); 1 real applicant shows a made-up 2–5", () => {
    expect(getCampaignStats({ id: "x", applicants: Array(20).fill(0) }).applied).toBe(8);
    expect(getCampaignStats({ id: "x", applicants: [1] }).applied).toBeGreaterThanOrEqual(2);
    expect(getCampaignStats({ id: "x", applied: 15 }).views).toBe(20); // above the "10–15" the comment promises
  });
  it("avatars: 2..4", () => {
    expect(getCampaignAvatars({ id: "x" }, 9).length).toBe(4);
    expect(getCampaignAvatars(null, 0).length).toBe(2);
  });
});
