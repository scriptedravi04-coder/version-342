import { describe, it, expect } from "vitest";
import { readFileSync } from "fs";

const read = (p: string) => readFileSync(p, "utf8");
const D = "src/components/landing/v2/LandingDesktopView.jsx";
const M = "src/components/landing/v2/LandingMobileView.jsx";
const NEWS = ["n-a", "n-h1", "n-h2", "n-h3", "n-sub", "n-col", "n-pic", "n-stamp"];

// v342 (Ravi: "landing page fat raha hai"): Eva's dashed lines were invisible (lowercase <lineargradient> is not an
// SVG gradient, so stroke="url(#evaLine)" painted nothing → a big empty gap), and the newspaper emptied itself every
// 10 s (looked broken half the time).
describe("v342 · landing fixes", () => {
  it("no lowercase SVG camelCase tags (React would render them as unknown elements)", () => {
    for (const f of [D, M]) expect(read(f)).not.toMatch(/<(lineargradient|radialgradient|clippath|fegaussianblur|foreignobject|textpath)\b/);
    expect(read(D)).toContain("<linearGradient id=\"evaLine\"");
  });
  it("newspaper prints once when it is on screen, then stays complete", () => {
    for (const [f, css] of [[D, "src/components/landing/v2/landingDesktop.css"], [M, "src/components/landing/v2/landingMobile.css"]]) {
      const s = read(f), c = read(css);
      for (const n of NEWS) {
        expect(s).not.toMatch(new RegExp(`animation: "${n} 10s [^"]*infinite"`));
        const kf = c.match(new RegExp(`@keyframes ${n}\\{.*?\\}\\}`))![0];
        expect(kf).not.toContain("97%");
      }
      expect(s).toContain('className={v.npPlay ? undefined : "np-wait"}');
      expect(s).toContain("new IntersectionObserver");
      expect(c).toContain(".np-wait *{animation-play-state:paused!important}");
    }
  });
});
