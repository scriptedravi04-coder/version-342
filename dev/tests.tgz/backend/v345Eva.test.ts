// v345 (tester Ankit, Eva): "I need to know about UGC" started the UGC builder; "Show it again" on an old chat
// re-sent "Skip" and got "Could you tell me a little more?"; a brief made with Eva didn't show on the UGC screen.
import { describe, it, expect } from "vitest";
import fs from "node:fs";
import path from "node:path";
import { detectBrandIntent, isInfoAsk } from "../src/components/assist/brand/brandLogic";
import { detectCreatorIntent } from "../src/components/assist/creator/creatorLogic";
import { plan, initialState } from "../src/components/feedback/assistBrain";

const read = (p: string) => fs.readFileSync(path.join(path.resolve(__dirname, ".."), p), "utf8");

describe("v345 — Eva answers questions instead of starting a brief", () => {
  it("brand: questions about UGC / campaigns are answered (null = knowledge answer)", () => {
    for (const q of ["I need to know about Ugc", "what is ugc", "UGC kya hai", "tell me about UGC videos", "how does a campaign work", "ugc samjhao"]) {
      const r = detectBrandIntent(q);
      expect(r?.intent === "ugcCreate" || r?.intent === "campaignCreate", q).toBe(false);
    }
    expect(isInfoAsk("what is ugc")).toBe(true);
  });
  it("brand: real requests still start the builder", () => {
    for (const q of ["I need ugc videos", "ugc banana hai", "create ugc for my serum", "need 3 ugc videos", "I want to know about ugc and make one"]) {
      expect(detectBrandIntent(q)?.intent, q).toBe("ugcCreate");
    }
    expect(detectBrandIntent("create a campaign for my brand")?.intent).toBe("campaignCreate");
  });
  it("creator: 'what is UGC' is answered, 'show UGC briefs' still lists", () => {
    expect(detectCreatorIntent("I need to know about UGC")).toBe(null);
    expect(detectCreatorIntent("what is ugc")).toBe(null);
    expect(detectCreatorIntent("show ugc briefs")?.intent).toBe("campaigns");
  });
});

describe("v345 — the answer is the UGC explanation, not a ticket", () => {
  it("'I need to know about Ugc' gets the UGC answer and nothing is sent to the team", () => {
    const r: any = plan("I need to know about Ugc", { ...initialState(), role: "brand" }, { role: "brand" });
    expect(r.send).toBe(null);
    expect(r.reply).toMatch(/UGC brief/);
  });
});

describe("v345 — Eva briefs don't get lost", () => {
  it("finished UGC brief is kept as the UGC draft right away (never over a hand-written one)", () => {
    expect(read("src/components/assist/brand/brain.js")).toContain("T.rememberUgcDraft(ugc)");
    const t = read("src/components/assist/brand/tools.js");
    expect(t).toContain("export function rememberUgcDraft");
    expect(t).toContain('cur.from !== "assist"');
  });
  it("UGC → My briefs shows the draft card with Resume / Discard", () => {
    const s = read("src/pages/brand/BrandUGCMobile.jsx");
    expect(s).toContain('data-testid="ugc-draft-card"');
    expect(s).toContain("onClick={handleResumeDraft}");
  });
  it("'Show it again' re-opens the saved brief card, never re-sends a one-word answer", () => {
    const s = read("src/components/feedback/FeedbackBot.jsx");
    expect(s).toContain("brandMod.currentDraft()");
    expect(s).toContain("split(/\\s+/).length >= 2");
    expect(read("src/components/assist/brand/index.js")).toContain("currentDraft");
  });
});
