// v349 (Ravi): admin "Hide from Explore & Meet the Creators" (creator_profiles.hidden_from_explore) and the
// logged-out Explore preview that fills whole grid rows.
import { describe, it, expect } from "vitest";
import fs from "fs";
import path from "path";
import express from "express";
import { visibleOnExplore, isHiddenFromExplore } from "./exploreGate";
import { isShowableCreator, autoHomePicks, landingCreatorCards, setupCreatorHomePicks } from "./creatorHomePicks";
import { matchSaved } from "./assist_store";
import { requiredAdminPermission } from "./adminPermissions";
import { visibleCreators, isHiddenFromExplore as isHiddenClient } from "../src/lib/visibleCreators.js";
import { guestPreviewCount, gridColumnCount } from "../src/lib/guestPreview.js";

const read = (p: string) => fs.readFileSync(path.resolve(__dirname, "..", p), "utf8");
const ok = (extra: any = {}) => ({ user_id: "u1", name: "Asha Rao", profile_status: "approved", picture: "https://p/1", ...extra });

describe("v349: hidden_from_explore filters", () => {
  it("flag parsing", () => {
    for (const v of [true, "true", 1]) { expect(isHiddenFromExplore({ hidden_from_explore: v })).toBe(true); expect(isHiddenClient({ hidden_from_explore: v })).toBe(true); }
    for (const v of [false, null, undefined, "false", 0]) { expect(isHiddenFromExplore({ hidden_from_explore: v })).toBe(false); expect(isHiddenClient({ hidden_from_explore: v })).toBe(false); }
  });
  it("public / brand Explore (visibleOnExplore) skips hidden creators", () => {
    expect(visibleOnExplore(ok())).toBe(true);
    expect(visibleOnExplore(ok({ hidden_from_explore: false }))).toBe(true);
    expect(visibleOnExplore(ok({ hidden_from_explore: true }))).toBe(false);
  });
  it("browser lists (visibleCreators) skip hidden creators", () => {
    const out = visibleCreators([ok({ user_id: "a" }), ok({ user_id: "b", hidden_from_explore: true })]);
    expect(out.map((c: any) => c.user_id)).toEqual(["a"]);
  });
  it("home picks, landing wall and Eva saved search skip hidden creators", () => {
    expect(isShowableCreator(ok())).toBe(true);
    expect(isShowableCreator(ok({ hidden_from_explore: true }))).toBe(false);
    const rows = [ok({ user_id: "a" }), ok({ user_id: "b", hidden_from_explore: true })];
    expect(autoHomePicks(rows, "x").map((p) => p.user_id)).toEqual(["a"]);
    expect(landingCreatorCards(rows).map((c) => c.id)).toEqual(["a"]);
    expect(matchSaved(rows, {}).map((c: any) => c.user_id)).toEqual(["a"]);
  });
});

async function serve(app: express.Express, fn: (base: string) => Promise<void>) {
  const srv = app.listen(0);
  await new Promise((r) => srv.once("listening", r));
  const port = (srv.address() as any).port;
  try { await fn(`http://127.0.0.1:${port}`); } finally { srv.close(); }
}
function homeApp(db: any, user: any, logs: any[] = []) {
  const app = express(); app.use(express.json());
  const router = express.Router();
  setupCreatorHomePicks(router, {
    supabase: null, privilegedSupabase: null, getDb: () => db, saveDb: () => {}, parseAuthUser: async () => user,
    logAdminAction: async (_u, action, type, id) => { logs.push({ action, type, id }); },
  });
  app.use("/api", router);
  return app;
}
const post = (base: string, uid: string, body: any) =>
  fetch(`${base}/api/admin/creators/${uid}/explore-hide`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });

describe("v349: admin explore-hide route", () => {
  it("admin hides and unhides; logged; ticked home pick then drops out", async () => {
    const db = { creator_profiles: [ok({ user_id: "c1", show_on_creator_home: true }), ok({ user_id: "c2", name: "Bina K", show_on_creator_home: true })] };
    const logs: any[] = [];
    await serve(homeApp(db, { user_id: "adm", role: "admin" }, logs), async (base) => {
      const r = await post(base, "c1", { hidden: true });
      expect(r.status).toBe(200);
      expect(await r.json()).toEqual({ ok: true, hidden: true });
      expect(db.creator_profiles[0].hidden_from_explore).toBe(true);
      const land = await (await fetch(base + "/api/landing-creators")).json();
      expect(land.creators.map((c: any) => c.id)).toEqual(["c2"]);
      const r2 = await post(base, "c1", { hidden: false });
      expect((await r2.json()).hidden).toBe(false);
      expect(db.creator_profiles[0].hidden_from_explore).toBe(false);
    });
    expect(logs.map((l) => l.action)).toEqual(["explore_hide_on", "explore_hide_off"]);
  });
  it("non-admin refused; unknown creator 404", async () => {
    const db = { creator_profiles: [ok({ user_id: "c1" })] };
    await serve(homeApp(db, { user_id: "b", role: "brand" }), async (base) => {
      expect((await post(base, "c1", { hidden: true })).status).toBe(403);
    });
    expect((db.creator_profiles[0] as any).hidden_from_explore).toBeUndefined();
    await serve(homeApp(db, { user_id: "adm", role: "admin" }), async (base) => {
      expect((await post(base, "nope", { hidden: true })).status).toBe(404);
    });
  });
  it("sub-admins need manage_users (global /admin gate)", () => {
    expect(requiredAdminPermission("POST", "/admin/creators/c1/explore-hide")).toBe("manage_users");
  });
});

describe("v349: guest Explore preview fills whole rows", () => {
  it("count is a multiple of the column count", () => {
    expect(guestPreviewCount(5, 50)).toBe(10);
    expect(guestPreviewCount(4, 50)).toBe(8);
    expect(guestPreviewCount(3, 50)).toBe(9);
    expect(guestPreviewCount(2, 50)).toBe(8);
    expect(guestPreviewCount(1, 50)).toBe(8);
    for (let c = 1; c <= 8; c++) expect(guestPreviewCount(c, 100) % c).toBe(0);
    expect(guestPreviewCount(5, 7)).toBe(7); // fewer creators → all of them, no blurred block
    expect(guestPreviewCount(0, 0)).toBe(0);
  });
  it("reads the computed grid template", () => {
    expect(gridColumnCount("240px 240px 240px 240px 240px")).toBe(5);
    expect(gridColumnCount("")).toBe(1);
    expect(gridColumnCount("none")).toBe(1);
  });
});

describe("v349: static checks", () => {
  it("Explore page uses the hidden filter and the whole-row preview", () => {
    const s = read("src/pages/dashboard/Explore.jsx");
    expect(s).toContain("isHiddenFromExplore(c)");
    expect(s).toContain("filteredCreators.slice(0, guestShown)");
    expect(s).not.toContain("filteredCreators.slice(0, 8).map");
  });
  it("server still filters /creators/explore through visibleOnExplore", () => {
    expect(read("backend/server.ts")).toContain("body.filter((r: any) => visibleOnExplore(r))");
  });
  it("admin panel has the toggle, the route call and the list chip", () => {
    expect(read("src/components/admin/UserEnforcementPanel.jsx")).toContain("<ExploreHideControl userId={targetUid}");
    const ctl = read("src/components/admin/ExploreHideControl.jsx");
    expect(ctl).toContain("admin/creators/${userId}/explore-hide");
    expect(ctl).toContain("Hide from Explore & Meet the Creators");
    expect(read("src/components/admin/AdminUsersTab.jsx")).toContain("Hidden from Explore");
  });
});
