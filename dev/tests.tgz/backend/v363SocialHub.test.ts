// v363 (Ravi's design 1a / 1b / 1c; Ravi: "social page pe do do baar insta aa raha hai" and "@narendramodi ke numbers
// aa gaye jabki username elite_ravi tha"): one Instagram card, a confirm step before saving, live numbers on the hub.
import { describe, it, expect } from "vitest";
import fs from "fs";
import { fmtK, fmtFull, fmtPct, cleanIgHandle, liveNumbers, agoShort } from "../src/components/instagram/igFormat";

const read = (p: string) => fs.readFileSync(p, "utf8");

describe("v363 — Instagram number helpers", () => {
  it("formats like the design, never invents a number", () => {
    expect(fmtK(10376)).toBe("10.4K");
    expect(fmtK(19379)).toBe("19.4K");
    expect(fmtK(1250000)).toBe("1.3M");
    expect(fmtK(950)).toBe("950");
    expect(fmtK(null)).toBe("—");
    expect(fmtFull(10376)).toBe("10,376");
    expect(fmtFull(undefined)).toBe("—");
    expect(fmtPct(11.214)).toBe("11.21%");
    expect(fmtPct(11.214, 1)).toBe("11.2%");
    expect(fmtPct(null)).toBe("—");
  });
  it("cleans usernames like the server", () => {
    expect(cleanIgHandle("@Elite_Ravi ")).toBe("elite_ravi");
    expect(cleanIgHandle("https://instagram.com/elite_ravi/?hl=en")).toBe("elite_ravi");
    expect(cleanIgHandle("bad..name")).toBe("");
    expect(cleanIgHandle("")).toBe("");
  });
  it("avg views falls back to 28-day reach; time is short", () => {
    expect(liveNumbers({ followers: 5, reach_28d: 900 }).avgViews).toBe(900);
    expect(liveNumbers(null).followers).toBeNull();
    expect(agoShort(new Date(Date.now() - 10 * 3600e3).toISOString())).toBe("10h ago");
  });
});

describe("v363 — 'Is this you?' before anything is saved", () => {
  const sheet = read("src/components/instagram/ConnectInstagramSheet.jsx");
  it("typing only previews; lookup (save) only inside the confirm handler", () => {
    expect(sheet).toContain('api.post("instagram/preview"');
    const lookupAt = sheet.indexOf('api.post("creator/instagram/lookup"');
    expect(lookupAt).toBeGreaterThan(sheet.indexOf("const connect = async"));
    expect(sheet.match(/api\.post\("creator\/instagram\/lookup"/g)?.length).toBe(1);
    expect(sheet).toContain("Yes, that's me — connect");
    expect(sheet).toContain("Not me, try another username");
  });
  it("the live card refreshes the SAME account and changes username only through the sheet", () => {
    const card = read("src/components/instagram/InstagramConnectCard.jsx");
    expect(card).toContain('api.post("creator/instagram/lookup", { username: st.handle })');
    expect(card).not.toMatch(/lookup",\s*\{\s*username\s*\}/); // no save of a freely typed username
    expect(card).toContain("<ConnectInstagramSheet");
    expect(card).toContain("Update username");
    expect(card).toContain("Verified by Ybex");
    expect(card).toContain("Brands see these numbers");
  });
});

describe("v363 — Social platforms shows Instagram once; hub shows it live", () => {
  it("Instagram is filtered out of the Added / Add-more lists while the live card shows", () => {
    const s = read("src/pages/creator/profileScreens/PlatformsScreen.jsx");
    expect(s).toContain("<InstagramConnectCard");
    expect(s).toContain('connectedSocials.filter((p) => !isIg(p))');
    expect(s).toContain('notConnectedSocials.filter((p) => !isIg(p))');
    expect(s).toContain("Disconnect Instagram");
    expect(s).toContain("disconnectInstagram");
    expect(read("backend/instagramConnect.ts")).toContain('router.post("/creator/instagram/disconnect"');
  });
  it("hub: live strip + row chips", () => {
    const m = read("src/pages/creator/CreatorMobileProfile.jsx");
    expect(m).toContain("<HubInstagramStrip profile={profile} />");
    expect(m).toContain("<HubIgHandle profile={profile} />");
    for (const t of ['"IG live"', '"Not set"', '"Verified"', "collab"]) expect(m).toContain(t);
  });
});
