// v366 (Ravi: "CSV mein email optional — bina email ke approve karne pe kuch toote nahi"): end to end through the REAL
// /admin/waitlist/import-csv and /admin/waitlist/:id/approve handlers with a fake Supabase that behaves like the live
// tables (waitlist.email nullable but unique when present, users.email NOT NULL, unknown columns refused).
import { describe, it, expect, vi, beforeEach } from "vitest";
import express from "express";

const sent: any[] = [];
vi.mock("resend", () => ({ Resend: class { emails = { send: async (m: any) => { sent.push(m); return { data: { id: "x" }, error: null }; } }; } }));

import { setupAdminWaitlistRoutes } from "./admin_waitlist_routes";
import { WAITLIST_COLUMNS, USERS_COLUMNS, CREATOR_PROFILE_COLUMNS } from "./creatorApplication";

const COLS: Record<string, string[] | null> = { waitlist: WAITLIST_COLUMNS, users: USERS_COLUMNS, creator_profiles: CREATOR_PROFILE_COLUMNS, brand_profiles: null, creator_kyc: null };
const unescape = (v: string) => String(v).replace(/\\([\\%_])/g, "$1");

function fakeDb() {
  const t: Record<string, any[]> = { waitlist: [], users: [], creator_profiles: [], brand_profiles: [], creator_kyc: [] };
  const check = (name: string, rows: any[]) => {
    const cols = COLS[name];
    if (cols) for (const r of rows) for (const k of Object.keys(r)) if (!cols.includes(k)) return { message: `Could not find the '${k}' column of '${name}'` };
    if (name === "users" && rows.some((r) => !r.email)) return { message: 'null value in column "email" of relation "users"' };
    if (name === "creator_profiles" && rows.some((r) => !r.name)) return { message: 'null value in column "name"' };
    if (name === "waitlist") {
      for (const r of rows) {
        if (r.email === "") return { message: "empty string email (should be null)" };
        if (r.email && t.waitlist.some((x) => x.email === r.email && x.id !== r.id)) return { message: 'duplicate key value violates unique constraint "waitlist_email_key"' };
      }
    }
    return null;
  };
  const from = (name: string) => {
    const filters: Array<(r: any) => boolean> = [];
    let patch: any = null;
    const rows = () => (t[name] || []).filter((r) => filters.every((f) => f(r)));
    const q: any = {
      select() { return q; }, order() { return q; }, range() { return q; },
      in(c: string, vs: any[]) { filters.push((r) => vs.map(String).includes(String(r[c]))); return q; },
      ilike(c: string, v: string) { filters.push((r) => String(r[c] || "").toLowerCase() === unescape(v).toLowerCase()); return q; },
      eq(c: string, v: any) {
        filters.push((r) => String(r[c]) === String(v));
        if (patch) { const bad = check(name, [{ ...rows()[0], ...patch }]); if (bad) return Promise.resolve({ error: bad }); rows().forEach((r) => Object.assign(r, patch)); return Promise.resolve({ error: null }); }
        return q;
      },
      limit() { return q; },
      maybeSingle() { return Promise.resolve({ data: rows()[0] || null, error: null }); },
      then(ok: any, bad: any) { return Promise.resolve({ data: rows(), error: null }).then(ok, bad); },
      insert(rs: any[]) { const arr = Array.isArray(rs) ? rs : [rs]; const err = check(name, arr); if (err) return Promise.resolve({ error: err }); t[name].push(...arr.map((r) => ({ ...r }))); return Promise.resolve({ error: null }); },
      upsert(rs: any[]) { const arr = Array.isArray(rs) ? rs : [rs]; const err = check(name, arr); if (err) return Promise.resolve({ error: err }); for (const r of arr) { const i = t[name].findIndex((x) => x.user_id === r.user_id); if (i >= 0) t[name][i] = { ...t[name][i], ...r }; else t[name].push({ ...r }); } return Promise.resolve({ error: null }); },
      update(p: any) { patch = p; return q; },
    };
    return q;
  };
  return { t, from };
}

async function call(app: any, method: string, path: string, body?: any) {
  const server = app.listen(0); const port = server.address().port;
  try {
    const r = await fetch(`http://127.0.0.1:${port}/api${path}`, { method, headers: { "content-type": "application/json" }, body: body ? JSON.stringify(body) : undefined });
    return { status: r.status, data: await r.json() };
  } finally { server.close(); }
}

function make() {
  const db = fakeDb();
  const local: any = {};
  const app = express(); app.use(express.json());
  const router = express.Router();
  setupAdminWaitlistRoutes(app, router, {
    supabase: db, privilegedSupabase: db, getDb: () => local, saveDb: () => {},
    parseAuthUser: async () => ({ user_id: "admin1", role: "admin" }), sendNotification: async () => {}, checkAdminPerm: async () => true,
  } as any);
  app.use("/api", router);
  return { app, db };
}

describe("v366 · CSV without email — real routes", () => {
  beforeEach(() => { sent.length = 0; process.env.RESEND_API_KEY = "re_test"; });

  it("imports handle-only rows, refuses duplicate handles, completes on re-upload, approves into ONE unclaimed profile, sends no email", async () => {
    const { app, db } = make();
    db.t.creator_profiles.push({ user_id: "real1", name: "Known", instagram_handle: "known_one", is_claimed: true });

    const first = await call(app, "POST", "/admin/waitlist/import-csv", { rows: [
      { name: "Riya", instagram: "@Riya_K" },
      { name: "Aman", instagram: "aman.creates" },
      { name: "Riya again", instagram_link: "https://instagram.com/riya_k/" },
      { name: "Known", instagram: "known_one" },
      { name: "Nobody" },
      { name: "Mail", email: "mail@x.in", instagram: "mail_x" },
    ] });
    expect(first.status).toBe(200);
    expect(first.data.imported).toBe(3);
    expect(first.data.results.map((r: any) => r.status)).toEqual(["ok", "ok", "duplicate", "duplicate", "error", "ok"]);
    const riya = db.t.waitlist.find((w) => w.social_handle === "Riya_K");
    expect(riya.email).toBeNull();
    expect(db.t.waitlist.filter((w) => w.email === null)).toHaveLength(2); // two null emails side by side — no unique clash

    // re-upload: same handle-only row with a new city → fills the empty cell, no new row
    const again = await call(app, "POST", "/admin/waitlist/import-csv", { rows: [{ name: "Riya", instagram: "riya_k", city: "Jaipur" }] });
    expect(again.status).toBe(200);
    expect(again.data.updated).toBe(1);
    expect(db.t.waitlist).toHaveLength(3);
    expect(riya.city).toBe("Jaipur");

    // approve → one unclaimed profile, placeholder login email, no email sent
    const a1 = await call(app, "POST", `/admin/waitlist/${riya.id}/approve`);
    expect(a1.status).toBe(200);
    expect(a1.data.ok).toBe(true);
    expect(a1.data.emailed).toBe(false);
    const shadow = db.t.users.find((u) => u.auth_method === "unclaimed");
    expect(shadow.email).toMatch(/@ybex\.io$/);
    const prof = db.t.creator_profiles.find((p) => p.user_id === shadow.user_id);
    expect(prof).toMatchObject({ instagram_handle: "Riya_K", is_claimed: false, email: null });
    expect(riya.status).toBe("Approved");

    // approving again never makes a second listing
    const a2 = await call(app, "POST", `/admin/waitlist/${riya.id}/approve`);
    expect(a2.status).toBe(200);
    expect(db.t.creator_profiles.filter((p) => String(p.user_id).startsWith("CRTR_UNCLAIMED_"))).toHaveLength(1);
    expect(sent).toHaveLength(0);

    // the list shows the handle-only row without crashing
    const list = await call(app, "GET", "/admin/waitlist");
    expect(list.status).toBe(200);
    expect(list.data.some((w: any) => w.handle === "aman.creates" && w.email === "")).toBe(true);
  });

  it("edit with an empty email box saves null (two blank emails never clash)", async () => {
    const { app, db } = make();
    await call(app, "POST", "/admin/waitlist/import-csv", { rows: [{ name: "A", instagram: "a_one" }, { name: "B", instagram: "b_two" }] });
    const [a, b] = db.t.waitlist;
    const r1 = await call(app, "PATCH", `/admin/waitlist/${a.id}`, { email: "", city: "Pune" });
    const r2 = await call(app, "PATCH", `/admin/waitlist/${b.id}`, { email: "  " });
    expect(r1.status).toBe(200);
    expect(r2.status).toBe(200);
    expect(a.email).toBeNull();
    expect(b.email).toBeNull();
    expect(a.city).toBe("Pune");
  });
});
