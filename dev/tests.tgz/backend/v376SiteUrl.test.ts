// v376 (live test of ybexmedia.in): robots.txt / sitemap.xml / blog canonicals pointed at https://ybexapp.ai.studio.
import { describe, it, expect, afterEach } from "vitest";
import fs from "fs";
import path from "path";
import { siteUrlFor } from "./blogSeo";

const keep = { SITE_URL: process.env.SITE_URL, APP_URL: process.env.APP_URL };
afterEach(() => { process.env.SITE_URL = keep.SITE_URL ?? ""; process.env.APP_URL = keep.APP_URL ?? ""; });

describe("v376 · public site address for SEO", () => {
  it("never uses the AI Studio / Cloud Run hosting address", () => {
    process.env.SITE_URL = "";
    process.env.APP_URL = "https://ybexapp.ai.studio";
    expect(siteUrlFor()).toBe("https://ybexmedia.in");
    process.env.APP_URL = "https://ybexapp-947523512509.asia-southeast1.run.app/";
    expect(siteUrlFor()).toBe("https://ybexmedia.in");
  });
  it("SITE_URL wins; a real APP_URL domain is kept", () => {
    process.env.SITE_URL = "https://www.ybexmedia.in/";
    process.env.APP_URL = "https://ybexapp.ai.studio";
    expect(siteUrlFor()).toBe("https://www.ybexmedia.in");
    process.env.SITE_URL = "";
    process.env.APP_URL = "https://ybexmedia.in";
    expect(siteUrlFor()).toBe("https://ybexmedia.in");
  });
  it("header Sign In / Get Ybex never wrap on a 375px phone; profile sign-in comes back to the creator", () => {
    const layout = fs.readFileSync(path.join(process.cwd(), "src/components/layout/Layout.jsx"), "utf8");
    expect(layout).toMatch(/data-testid="nav-login" className="whitespace-nowrap/);
    expect(layout).toMatch(/data-testid="nav-signup" className="whitespace-nowrap/);
    const view = fs.readFileSync(path.join(process.cwd(), "src/pages/creator/CreatorPublicView.jsx"), "utf8");
    expect(view).toContain("/login?role=brand&next=${encodeURIComponent(`/creator/${id}`)}");
  });
});
