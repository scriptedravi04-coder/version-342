// v349 (Ravi): real Instagram numbers — username fetch (Business Discovery), DM code, Instagram Login, daily refresh,
// and a guard so synced numbers can't be typed over.
import { describe, it, expect, beforeEach } from "vitest";
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import {
  cleanUsername, statsFromInstagram, profilePatchFromStats, graphError, makeDmCode, extractDmCode,
  validMetaSignature, sealToken, openToken, makeIgState, readIgState, igStatus, fetchByUsername, IG_METRIC_FIELDS,
} from "./instagramConnect";

const root = path.resolve(__dirname, "..");
const read = (p: string) => fs.readFileSync(path.join(root, p), "utf8");

describe("v349 — Instagram helpers", () => {
  it("cleans every way people type a username", () => {
    expect(cleanUsername("@It_Ankit.T0mar_204")).toBe("it_ankit.t0mar_204");
    expect(cleanUsername("https://www.instagram.com/chahatsainiii/?igsh=abc")).toBe("chahatsainiii");
    expect(cleanUsername("instagram.com/ybex.app")).toBe("ybex.app");
    expect(cleanUsername("bad name")).toBeNull();
    expect(cleanUsername("")).toBeNull();
    expect(cleanUsername(".dot")).toBeNull();
  });
  it("computes averages + engagement from the last posts (views only from reels)", () => {
    const s = statsFromInstagram({ username: "Ankit", followers_count: 15000, media_count: 80 }, [
      { like_count: 900, comments_count: 100, media_product_type: "REELS", view_count: 40000 },
      { like_count: 1100, comments_count: 100, media_product_type: "REELS", view_count: 60000 },
      { like_count: 500, comments_count: 50, media_type: "IMAGE" },
    ]);
    expect(s.followers).toBe(15000);
    expect(s.avg_likes).toBe(833);
    expect(s.avg_views).toBe(50000);
    expect(s.engagement_rate).toBeCloseTo(((833 + 83) / 15000) * 100, 1);
    expect(s.username).toBe("ankit");
  });
  it("profile patch writes live numbers and never zero views", () => {
    const p = profilePatchFromStats(statsFromInstagram({ username: "a", followers_count: 12 }, []), "2026-10-19T00:00:00Z");
    expect(p.followers_instagram).toBe(12);
    expect(p.instagram_synced_at).toBe("2026-10-19T00:00:00Z");
    expect(p).not.toHaveProperty("avg_views_30d");
  });
  it("Meta errors → plain words", () => {
    expect(graphError({ error: { code: 110, error_subcode: 2207013, message: "Cannot find User" } }).code).toBe("NOT_PROFESSIONAL");
    expect(graphError({ error: { code: 4 } }).code).toBe("RATE_LIMIT");
    expect(graphError({ error: { code: 190 } }).code).toBe("TOKEN");
  });
  it("DM codes", () => {
    const c = makeDmCode();
    expect(c).toMatch(/^YBX-[A-Z2-9]{6}$/);
    expect(extractDmCode(`hi ${c.toLowerCase()} thanks`)).toBe(c);
    expect(extractDmCode("ybx 4K7PQZ")).toBe("YBX-4K7PQZ");
    expect(extractDmCode("hello")).toBeNull();
  });
  it("webhook signature", () => {
    const raw = Buffer.from('{"object":"instagram"}');
    const sig = "sha256=" + crypto.createHmac("sha256", "sec").update(raw).digest("hex");
    expect(validMetaSignature(raw, sig, "sec")).toBe(true);
    expect(validMetaSignature(raw, sig, "other")).toBe(false);
    expect(validMetaSignature(raw, undefined, "sec")).toBe(false);
  });
  it("tokens are sealed; OAuth state is signed and expires", () => {
    const sealed = sealToken("IGQ-secret");
    expect(sealed).not.toContain("IGQ-secret");
    expect(openToken(sealed)).toBe("IGQ-secret");
    const st = makeIgState("user1", 1000);
    expect(readIgState(st, 2000)).toBe("user1");
    expect(readIgState(st, 1000 + 16 * 60 * 1000)).toBeNull();
    expect(readIgState(st.replace(/.$/, "x"), 2000)).toBeNull();
  });
  it("status: changing the handle drops sync / verified", () => {
    const row = { instagram_handle: "a", instagram_synced_at: "x", instagram_verified_at: "y", instagram_stats: { username: "a", followers: 1 } };
    expect(igStatus(row).verified).toBe(true);
    expect(igStatus({ ...row, instagram_handle: "b" }).verified).toBe(false);
    expect(igStatus({ ...row, instagram_stats: { username: "a", error: "not_professional" } }).last_error).toBe("not_professional");
  });
});

describe("v349 — Business Discovery call", () => {
  beforeEach(() => { process.env.IG_GRAPH_TOKEN = "tok"; process.env.IG_BUSINESS_ID = "1784"; });
  it("asks Ybex's own account for the username and reads the numbers", async () => {
    let asked = "";
    const fake: any = async (url: string) => { asked = url; return { ok: true, json: async () => ({ business_discovery: { username: "ankit", followers_count: 15200, media: { data: [{ like_count: 10, comments_count: 2 }] } } }) }; };
    const s = await fetchByUsername("ankit", fake);
    expect(decodeURIComponent(asked)).toContain("business_discovery.username(ankit)");
    expect(asked).toContain("/1784?");
    expect(s.followers).toBe(15200);
  });
  it("personal / unknown account → NOT_PROFESSIONAL", async () => {
    const fake: any = async () => ({ ok: false, status: 400, json: async () => ({ error: { code: 110, error_subcode: 2207013, message: "Cannot find User" } }) });
    await expect(fetchByUsername("someone", fake)).rejects.toBeTruthy();
    try { await fetchByUsername("someone", fake); } catch (e) { expect(graphError(e).code).toBe("NOT_PROFESSIONAL"); }
  });
});

describe("v349 — wiring", () => {
  it("routes registered before the creators routes; webhook gets the raw body", () => {
    const s = read("backend/server.ts");
    expect(s.indexOf("setupInstagramRoutes(router")).toBeGreaterThan(0);
    expect(s.indexOf("setupInstagramRoutes(router")).toBeLessThan(s.indexOf("setupCreatorsRoutes(app, router"));
    expect(s).toContain('app.use("/api/webhooks/instagram", express.raw(');
  });
  it("the browser can't write the new staff-only columns", () => {
    const s = read("backend/browserDbRoutes.ts");
    for (const c of ["hidden_from_explore", "instagram_verified_at", "instagram_synced_at", "instagram_stats"]) expect(s).toContain(c);
  });
  it("synced numbers can't be typed over (metric fields stripped)", () => {
    expect(IG_METRIC_FIELDS).toContain("ig_followers");
    expect(IG_METRIC_FIELDS).toContain("avg_views_30d");
    expect(read("backend/instagramConnect.ts")).toContain('router.post("/creators/profile"');
  });
  it("creator screens show the card", () => {
    expect(read("src/pages/creator/profileScreens/PlatformsScreen.jsx")).toContain("<InstagramConnectCard");
    expect(read("src/pages/creator/CreatorSettings.jsx")).toContain("<InstagramConnectCard");
  });
});
