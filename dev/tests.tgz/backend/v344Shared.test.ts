import { describe, it, expect } from "vitest";
import fs from "fs";
import path from "path";

// v344: shared / backend fixes (source checks).
const ROOT = path.resolve(__dirname, "..");
const read = (p: string) => fs.readFileSync(path.resolve(ROOT, p), "utf8");

describe("v344 shared fixes", () => {
  it("1. upload/AI timeouts beat the merged 30 s default", () => {
    const s = read("src/lib/api.js");
    expect((s.match(/config\.timeout === api\.defaults\.timeout/g) || []).length).toBe(2);
  });

  it("2. refreshUser keeps the same user object; login stores media_key", () => {
    const s = read("src/contexts/AuthContext.jsx");
    expect(s).toContain("setUser(prev => (JSON.stringify(prev) === JSON.stringify(u) ? prev : u));");
    expect(s).toMatch(/rememberMediaKey\(data\);\s*Promise\.resolve\(\)\.then\(\(\) => refreshUser\(\)\)\.catch\(\(\) => \{\}\);/);
  });

  it("3. Layout keeps one pending flag per poller", () => {
    const s = read("src/components/layout/Layout.jsx");
    expect(s).toContain("const hasPendingWork = ugcPending || dealsPending;");
    expect(s).not.toContain("setHasPendingWork(");
    expect(s).toContain("}, [user?.user_id, user?.role]);");
  });

  it("4. notifications accept broadcasts, guard Notification, track the cooldown, guard early", () => {
    const p = read("src/components/NotificationPopup.jsx");
    expect(p).toContain('notif.user_id === "all"');
    expect(p).toContain('typeof Notification !== "undefined" && Notification.permission');
    expect(p).toContain("gapTimerRef.current = setTimeout(");
    const b = read("src/components/shared/NotificationBell.jsx");
    expect(b).toContain('notif.user_id === "all"');
    expect(b.indexOf("if (!userId) return;")).toBeLessThan(b.indexOf("const pollInterval = setInterval("));
  });

  it("5. notification read/ack report supabase errors; tag create is signed-in and validated", () => {
    const s = read("backend/tags_notifications_routes.ts");
    expect((s.match(/res\.status\(502\)/g) || []).length).toBeGreaterThanOrEqual(2);
    const create = s.slice(s.indexOf('router.post("/tags/create"'));
    expect(create).toContain("parseAuthUser(req)");
    expect(create).toContain("cleanName.length > 40");
    expect(create).toContain("t.toLowerCase() === cleanName.toLowerCase()");
  });

  it("6. BottomNav retries a new photo URL", () => {
    expect(read("src/components/layout/BottomNav.jsx")).toContain("useEffect(() => { setNavPhotoBroken(false); }, [rawNavPhoto]);");
  });

  it("7. promo events need a signed-in user", () => {
    const s = read("backend/promo_routes.ts");
    const ev = s.slice(s.indexOf('router.post("/promos/:id/event"'), s.indexOf('router.get("/admin/promos"'));
    expect(ev).toContain("parseAuthUser(req)");
    expect(ev).toContain("res.status(401)");
  });

  it("8. profile banner cache is keyed per account", () => {
    const s = read("src/components/promo/ProfileBanner.jsx");
    expect(s).toContain("return `${KEY}:${k}`;");
    expect(s).toContain("if (k !== memKey) { memKey = k; mem = undefined; inflight = null; }");
  });

  it("9. crash checker knows PopStateEvent", () => {
    expect(read("scripts/check-crashes.mjs")).toContain('"PopStateEvent"');
  });
});
