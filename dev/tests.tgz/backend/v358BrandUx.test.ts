import { describe, it, expect } from "vitest";
import fs from "fs";
const read = (p: string) => fs.readFileSync(p, "utf8");

describe("v358 · brand-side UI/UX bug hunt", () => {
  it("phone campaign detail has side padding; Explore niche pill shows a short name with a real ellipsis", () => {
    expect(read("src/components/campaigns/mobile/BrandCampaignDetailMobile.jsx")).toContain('text-[#0A0A0A] px-4 pb-4'); // v360: bottom padding trimmed
    expect(read("src/components/explore/mobile/ExploreMobile.jsx")).toContain('String(niche).split(" & ")[0]');
  });
  it("brand home: default banners are text cards, no stock photo promise, Payments tile", () => {
    const s = read("src/pages/brand/BrandHomeMobile.jsx");
    expect(s).toContain("activeBanner.isDefault ?");
    expect(s).not.toContain("Receive raw 4K footage & ad hooks in under 48 hours");
  });
  it("UGC: no creator timer while a draft waits for the brand; no auto-release promise", () => {
    const s = read("src/pages/brand/brandUgc/OrdersTab.jsx");
    expect(s).toContain("!isInReview");
    expect(s).not.toMatch(/automatically if the SLA timer runs out/);
  });
  it("no invented numbers in the brand tour / desktop explore", () => {
    expect(read("src/components/dashboard/TourRunner.jsx")).not.toContain("4M+");
  });
  it("desktop inbox: local initials (no third-party avatar) and its own 'select a chat' panel", () => {
    const s = read("src/pages/dashboard/Chat.jsx");
    expect(s).not.toContain("api.dicebear.com");
    expect(s).toContain("PersonPhoto");
  });
  it("editing a live campaign: no 'Save draft', says it goes back to review", () => {
    expect(read("src/pages/brand/BrandCampaignCreate.jsx")).toMatch(/Send changes for review/);
    expect(read("src/components/campaigns/mobile/MobileCampaignCreate.jsx")).toMatch(/Send changes for review/);
  });
  it("brand KYC: approved brands are warned before resubmitting; more-info-needed is handled", () => {
    expect(read("src/pages/brand/BrandKycMobile.jsx")).toMatch(/sends your verification for review again/);
    expect(read("src/components/profile/mobile/brand/KycScreen.jsx")).toContain("needsInfo");
  });
});
